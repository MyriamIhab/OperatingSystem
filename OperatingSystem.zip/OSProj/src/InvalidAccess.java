
public class InvalidAccess extends Exception {
	public InvalidAccess() {
		super();
	}

	public InvalidAccess(String s) {
		super(s);
	}
}
