
public enum PCBState {
    READY,BLOCKED,RUNNING,FINISHED
}
